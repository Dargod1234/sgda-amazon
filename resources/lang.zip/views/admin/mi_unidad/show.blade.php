@extends('layouts.admin')

@section('content')
    <div class="container py-4">
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">{{ $carpeta->nombre }}</h1>
            </div>
            <div class="col-sm-6">
                <ol class="float-sm-right">
                    <button onclick="window.history.back();" class="btn btn-default">
                        <i class="bi bi-arrow-left"></i> Volver
                    </button>

                    <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal_crear_carpeta">
                        <i class="bi bi-folder-fill"></i> Crear Carpeta
                    </button>

                    <button type="button" class="btn btn-info" data-toggle="modal" data-target="#uploadModal">
                        <i class="bi bi-cloud-upload-fill"></i> Subir Archivos
                    </button>
                </ol>
            </div>
        </div>

        <!-- Resto del código del modal para subir archivos y crear carpetas sigue igual -->
        <!-- Modal para subir archivos -->
        <div class="modal fade" id="uploadModal" tabindex="-1" aria-labelledby="uploadModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="uploadModalLabel">Subir Archivos</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <!-- Información de la carpeta de destino -->
                        <div class="form-group">
                            <label for="folder">Carpeta Destino</label>

                            <h6>{{ $carpeta->nombre }}</h6>
                        </div>


                        <form action="{{ route('archivo.upload_file') }}" method="POST" enctype="multipart/form-data">
                            @csrf

                            <div class="form-group">
                                <label for="fileInput" class="btn btn-primary btn-block">
                                    <i class="bi bi-cloud-upload"></i> Seleccionar Archivos
                                </label>
                                <input type="file" name="file[]" id="fileInput" class="d-none" multiple />
                                <small class="form-text text-muted">Arrastra y suelta los archivos o haz clic para
                                    seleccionarlos. Puedes seleccionar varios archivos.</small>
                                <div id="fileList" class="mt-3"></div>
                                <input type="hidden" name="folder_id" value="{{ $carpeta->id }}">
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Subir Archivo</button>
                    </div>
                    </form>

                </div>
            </div>
        </div>


        <!-- Modal para Crear Carpeta -->
        <div class="modal fade" id="modal_crear_carpeta" tabindex="-1" aria-labelledby="modalCrearCarpetaLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <form action="{{ route('mi_unidad.store_subfolder') }}" method="POST">
                    @csrf
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modalCrearCarpetaLabel">Nueva Carpeta</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="nombre">Nombre de la Carpeta</label>
                                        <input type="text" id="nombre" name="nombre" class="form-control" required>
                                        <input type="hidden" id="carpeta_padre_id" name="carpeta_padre_id"
                                            value="{{ $carpeta->id }}" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label for="color">Color de la Carpeta</label>
                                        <div id="color-picker"></div> <!-- Elemento para el picker -->
                                        <input type="hidden" id="color" name="color" value="#ebc034">
                                        <!-- Campo oculto para almacenar el valor seleccionado -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-primary">Guardar Nueva Carpeta</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>

    <hr>
    <h5>Subcarpetas</h5>

    <style>
        .custom-file-input {
            cursor: pointer;
        }

        .custom-file-input::before {
            content: 'Selecciona archivos';
            display: block;
            width: 100%;
            height: 100%;
            background: #007bff;
            color: white;
            text-align: center;
            line-height: 2.5;
            border-radius: 0.25rem;
            font-size: 1rem;
        }

        .custom-file-input::after {
            content: '';
        }

        .custom-file-input:focus {
            outline: none;
            box-shadow: none;
        }

        .custom-file-input::file-selector-button {
            display: none;
        }

        .dropdown-toggle {
            background: white;
            border: 0;
        }

        .dropdown-toggle::after {
            display: none;
        }

        .col-2 {
            display: flex;
            justify-content: flex-end;
            align-items: center;
        }

        .divcontent {
            background: white;
            border: 1px solid #c0c0c0;
            border-radius: 10px;
            margin: 2px;
        }

        .divcontent:hover {
            box-shadow: 0 0 7px rgba(0, 0, 0, 0.5);
            transition: box-shadow 0.3s;
        }
    </style>

    @if ($subcarpetas->isNotEmpty())
        <div class="row my-4">
            @foreach ($subcarpetas as $subcarpeta)
                <div class="col-md-3 mb-3 mx-2 divcontent">
                    <div class="row d-flex justify-content-between" style="padding: 12px">
                        <div class="col-2">
                            <a href="{{ url('admin/mi_unidad/carpeta/' . $subcarpeta->id) }}" style="color:black;">
                                <i class="bi bi-folder-fill me-2"
                                    style="color: {{ $subcarpeta->color ?? '#ebc034' }}; font-size:20px;"></i>
                            </a>
                        </div>
                        <div class="col-8" style="margin-top:5px">
                            <a href="{{ url('admin/mi_unidad/carpeta/' . $subcarpeta->id) }}" style="color:black;">
                                <h6>{{ $subcarpeta->nombre }}</h6>
                            </a>
                        </div>
                        <div class="col-2">
                            <div class="dropdown">
                                <button class="dropdown-toggle" type="button" data-toggle="dropdown"
                                    aria-expanded="false">
                                    <i class="bi bi-three-dots-vertical"></i>
                                </button>
                                <div class="dropdown-menu">
                                    <button class="dropdown-item" type="button" data-toggle="modal"
                                        data-target="#modal_editar_{{ $subcarpeta->id }}">
                                        <i class="bi bi-pencil" style="margin:3px"></i> Editar
                                    </button>
                                    <button class="dropdown-item" type="button" data-toggle="modal"
                                        data-target="#modal_eliminar_{{ $subcarpeta->id }}">
                                        <i class="bi bi-trash" style="margin:3px"></i> Eliminar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Modales para editar y eliminar carpetas siguen igual -->
                    <div class="modal fade" id="modal_editar_{{ $subcarpeta->id }}" tabindex="-1"
                        aria-labelledby="modalEditarCarpetaLabel_{{ $subcarpeta->id }}" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <form action="{{ route('mi_unidad.update_subfolder') }}" method="POST">
                                @csrf
                                @method('PUT')
                                <input type="hidden" value="{{ $subcarpeta->id }}" name="id">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="modalEditarCarpetaLabel_{{ $subcarpeta->id }}">
                                            Editar
                                            Carpeta</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="nombre">Nombre de la Carpeta</label>
                                                    <input type="text" id="nombre_{{ $subcarpeta->id }}"
                                                        name="nombre" class="form-control"
                                                        value="{{ $subcarpeta->nombre }}" required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Cancelar</button>
                                        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="modal fade" id="modal_eliminar_{{ $subcarpeta->id }}" tabindex="-1"
                        aria-labelledby="modalEliminarLabel_{{ $subcarpeta->id }}" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="modalEliminarLabel_{{ $subcarpeta->id }}">Confirmar
                                        Eliminación</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    ¿Está seguro de que desea eliminar la carpeta "{{ $subcarpeta->nombre }}"? Esta acción
                                    no
                                    se puede deshacer.
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-dismiss="modal">Cancelar</button>
                                    <!-- Formulario para eliminar carpeta -->
                                    <form action="{{ route('mi_unidad.destroy_subfolder', $subcarpeta->id) }}"
                                        method="POST">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger">Eliminar Carpeta</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    @else
        <p class="text-muted">No hay sub-carpetas disponibles para seleccionar.</p>
    @endif

    <h5>Archivos en esta Carpeta</h5>

    <div class="container py-4">
        @if ($archivos->isNotEmpty())
            <div class="row">
                @foreach ($archivos as $archivo)
                    <div class="col-md-3 mb-4">
                        <div class="card">

                            <div class="card-body text-center">
                                @php
                                    $fileExtension = pathinfo($archivo->nombre, PATHINFO_EXTENSION);
                                @endphp

                                @if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif', 'jfif']))
                                    <img src="https://drive.google.com/uc?export=view&id={{ $archivo->google_drive_file_id }}"
                                        class="img-thumbnail" style="max-width: 65px; height: auto;">
                                @else
                                    <i class="fas fa-file-alt fa-3x"></i>
                                @endif


                                <p class="mt-2">{{ $archivo->nombre }}</p>

                                <div class="file-item">
                                    @if ($archivo->permisos->isNotEmpty() && $archivo->permisos[0]->ver)
                                        <a href="{{ route('archivo.show', $archivo->id) }}" class="btn btn-info btn-sm"
                                            data-toggle="tooltip" title="Ver" target="_blank">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                    @else
                                        <button class="btn btn-info btn-sm" disabled
                                            title="No tienes permisos para ver. Dile al administrador que te los otorgue.">
                                            <i class="bi bi-eye"
                                                style="color: gray; opacity: 0.5; pointer-events: none;"></i>
                                        </button>
                                    @endif


                                    @if ($archivo->permisos->isNotEmpty() && $archivo->permisos[0]->descargar)
                                        <!-- Descargar permiso -->
                                        <a href="{{ route('archivo.download', $archivo->id) }}"
                                            class="btn btn-success btn-sm" data-toggle="tooltip" title="Descargar">
                                            <i class="bi bi-download"></i>
                                        </a>
                                    @else
                                        <button class="btn btn-success btn-sm" disabled
                                            title="No tienes permisos para descargar. Dile al administrador que te los otorgue.">
                                            <i class="bi bi-download"
                                                style="color: gray; opacity: 0.5; pointer-events: none;"></i>
                                        </button>
                                    @endif

                                    @if ($archivo->permisos->isNotEmpty() && $archivo->permisos[0]->editar)
                                        <a href="{{ route('archivo.edit', ['id' => $archivo->id]) }}"
                                            class="btn btn-warning btn-sm" data-toggle="tooltip" title="Editar" target="_blank">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                    @else
                                        <button class="btn btn-warning btn-sm" disabled
                                            title="No tienes permisos para editar. Dile al administrador que te los otorgue.">
                                            <i class="bi bi-pencil"
                                                style="color: gray; opacity: 0.5; pointer-events: none;"></i>
                                        </button>
                                    @endif

                                    @if ($archivo->permisos->isNotEmpty() && $archivo->permisos[0]->eliminar)
                                        <!-- Eliminar permiso -->
                                        <form action="{{ route('archivo.mover-a-papelera', $archivo->id) }}"
                                            method="POST" style="display:inline;">
                                            @csrf
                                            @method('DELETE')
                                            <input type="text" value="{{ $carpeta->id }}" name="carpeta_id" hidden>
                                            <button type="submit" class="btn btn-danger btn-sm" data-toggle="tooltip"
                                                title="Eliminar">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    @else
                                        <button class="btn btn-danger btn-sm" disabled
                                            title="No tienes permisos para eliminar. Dile al administrador que te los otorgue.">
                                            <i class="bi bi-trash"
                                                style="color: gray; opacity: 0.5; pointer-events: none;"></i>
                                        </button>
                                    @endif
                                </div>
                            </div>

                        </div>
                    </div>
                @endforeach
            </div>
        @else
            <p>No hay archivos en esta carpeta.</p>
        @endif
    </div>
@endsection

@push('scripts')
    <script>
        document.getElementById('fileInput').addEventListener('change', function(event) {
            const fileList = document.getElementById('fileList');
            fileList.innerHTML = ''; // Clear existing file list

            for (const file of event.target.files) {
                const fileItem = document.createElement('div');
                fileItem.className = 'file-list-item';
                fileItem.innerHTML = `<i class="bi bi-file-earmark"></i> ${file.name}`;
                fileList.appendChild(fileItem);
            }
        });
    </script>
@endpush
