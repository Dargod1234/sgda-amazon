@extends('layouts.admin')

@section('content')
    <br>
    <div class="d-flex justify-content-center flex-column">
        <div class="row col-md-12 pt-10 justify-content-center">
            <h1>Datos del usuario</h1>
        </div>
        <div class="row justify-content-left">
            <div class="col-md-6">
                <div class="card card-outline card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Datos registrados</h3>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">Nombre del usuario</label>
                                    <p>{{ $user->name }}</p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">Correo</label>
                                    <p>{{ $user->email }}</p>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-12">
                                <a href="{{ url('admin/users') }}" class="btn btn-secondary">Volver</a>
                                <a href="{{ route('user.unit', $user->id) }}" class="btn btn-secondary">Ver Carpetas</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
