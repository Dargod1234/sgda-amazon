@extends('layouts.admin')

@section('content')
    <div class="container px-4 py-4">
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Historial de Actividades</h1>
            </div>
        </div>

        @if ($activities->isNotEmpty())
            <hr>
            <h5>Actividades Registradas</h5>
            <div class="table-responsive p-4">
                <table class="table table-striped table-bordered custom-table">
                    <thead class="thead-dark">
                        <tr>
                            <th>Usuario</th>
                            <th>Acción</th>
                            <th>Archivo</th>
                            <th>Fecha</th>
                            <th>Actividad</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($activities as $activity)
                            <tr>
                                <td>{{ $activity->user->name }}</td>
                                <td>{{ ucfirst($activity->action) }}</td>
                                <td>
                                    @if (isset($files[$activity->file_id]))
                                        {{ $files[$activity->file_id]->nombre }}
                                    @else
                                        <span class="text-danger">Archivo Eliminado</span>
                                    @endif
                                </td>
                                <td>{{ $activity->performed_at }}</td>
                                <td>
                                    @if (isset($files[$activity->file_id]))
                                        <a href="{{ route('files.activity', $files[$activity->file_id]->id) }}"
                                            class="btn btn-info btn-sm">
                                            <i class="bi bi-activity"></i>
                                        </a>
                                    @else
                                        <button class="btn btn-secondary btn-sm" disabled>
                                            No disponible
                                        </button>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                <div class="mt-3">
                    {{ $activities->links() }}
                </div>
            </div>
        @else
            <p class="text-muted">No hay actividades registradas.</p>
        @endif
    </div>
@endsection
