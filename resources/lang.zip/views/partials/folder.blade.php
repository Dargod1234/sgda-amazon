<div class="d-flex justify-content-between align-items-center">
    <!-- Contenedor para el nombre de la carpeta -->
    <a class="folder-toggle text-decoration-none" style="margin-left: 15px;" data-folder-id="{{ $folder->id }}"
        role="button">
        <i class="bi bi-folder"></i> {{ $folder->nombre }}
    </a>
    <div class="flex-grow-1 mx-2">
        <hr style="border: 1px solid #b4b4b4; margin: 0;" />
    </div>
    <!-- Contenedor para los checkboxes de permisos -->
    <div class="d-flex align-items-center ms-3">
        @php
            $permisoCarpeta = $folder->permisos->where('user_id', $user->id)->first();
        @endphp

        <div class="form-check form-check-inline d-flex align-items-center">
            <input type="checkbox" class="form-check-input" id="check-view-folder-{{ $folder->id }}"
                name="permisos[carpeta][{{ $folder->id }}][ver]"
                {{ $permisoCarpeta && $permisoCarpeta->ver ? 'checked' : '' }}>
            <label class="form-check-label" for="check-view-folder-{{ $folder->id }}">
                <i class="bi bi-eye" style="font-size: 1.33em;"></i>
            </label>
        </div>
        <div class="form-check form-check-inline d-flex align-items-center" style="display: none !important;">
            <input type="checkbox" class="form-check-input" id="check-download-folder-{{ $folder->id }}"
                name="permisos[carpeta][{{ $folder->id }}][descargar]"
                {{ $permisoCarpeta && $permisoCarpeta->descargar ? 'checked' : '' }}>
            <label class="form-check-label" for="check-download-folder-{{ $folder->id }}">
                <i class="bi bi-download" style="font-size: 1.33em;"></i>
            </label>
        </div>

    </div>
</div>

<!-- Colapsable para carpetas hijas y archivos -->
<div class="collapse ms-3" id="folder-{{ $folder->id }}">
    {{-- Subcarpetas --}}
    @if ($folder->carpetasHijas->count() > 0)
        <ul class="list-unstyled mb-0">
            @foreach ($folder->carpetasHijas as $subfolder)
                <li>
                    @include('partials.folder', ['folder' => $subfolder])
                </li>
            @endforeach
        </ul>
    @endif

    {{-- Archivos en la carpeta --}}
    @if ($folder->archivos->count() > 0)
        <ul class="list-unstyled mb-0">
            @foreach ($folder->archivos as $archivo)
                <li class="d-flex align-items-center w-100">
                    <!-- Contenedor para el nombre del archivo -->
                    <div class="d-flex align-items-center me-3">
                        <i class="bi bi-file-earmark"></i>
                        <span class="ms-2">{{ $archivo->nombre }}</span>
                    </div>

                    <!-- Línea que conecta el archivo con los permisos -->
                    <div class="flex-grow-1 mx-2">
                        <hr style="border: 1px solid #b4b4b4; margin: 0;" />
                    </div>

                    <!-- Contenedor para los checkboxes de permisos -->
                    <div class="d-flex align-items-center ms-3">
                        @php
                            $permisoArchivo = $archivo->permisos->where('user_id', $user->id)->first();
                        @endphp

                        <div class="form-check form-check-inline d-flex align-items-center">
                            <input type="checkbox" class="form-check-input" id="check-download-{{ $archivo->id }}"
                                name="permisos[file][{{ $archivo->id }}][descargar]"
                                {{ $permisoArchivo && $permisoArchivo->descargar ? 'checked' : '' }}>
                            <label class="form-check-label" for="check-download-{{ $archivo->id }}">
                                <i class="bi bi-download" style="font-size: 1.33em;"></i>
                            </label>
                        </div>
                        <div class="form-check form-check-inline d-flex align-items-center">
                            <input type="checkbox" class="form-check-input" id="check-edit-{{ $archivo->id }}"
                                name="permisos[file][{{ $archivo->id }}][editar]"
                                {{ $permisoArchivo && $permisoArchivo->editar ? 'checked' : '' }}>
                            <label class="form-check-label" for="check-edit-{{ $archivo->id }}">
                                <i class="bi bi-pencil-square" style="font-size: 1.33em;"></i>
                            </label>
                        </div>
                        <div class="form-check form-check-inline d-flex align-items-center">
                            <input type="checkbox" class="form-check-input" id="check-delete-{{ $archivo->id }}"
                                name="permisos[file][{{ $archivo->id }}][eliminar]"
                                {{ $permisoArchivo && $permisoArchivo->eliminar ? 'checked' : '' }}>
                            <label class="form-check-label" for="check-delete-{{ $archivo->id }}">
                                <i class="bi bi-trash" style="font-size: 1.33em;"></i>
                            </label>
                        </div>
                        <div class="form-check form-check-inline d-flex align-items-center">
                            <input type="checkbox" class="form-check-input" id="check-view-{{ $archivo->id }}"
                                name="permisos[file][{{ $archivo->id }}][ver]"
                                {{ $permisoArchivo && $permisoArchivo->ver ? 'checked' : '' }}>
                            <label class="form-check-label" for="check-view-{{ $archivo->id }}">
                                <i class="bi bi-eye" style="font-size: 1.33em;"></i>
                            </label>
                        </div>
                    </div>
                </li>
            @endforeach
        </ul>
    @endif
