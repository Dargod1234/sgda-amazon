@php
    $user = null;
    if ($folder->archivos->isNotEmpty()) {
        $user = \App\Models\User::find($folder->archivos->first()->user_id);
    }
@endphp

<div class="folder-item">
    <div class="d-flex justify-content-between align-items-center">
        <a class="folder-toggle text-decoration-none" style="margin-left: 15px;" data-folder-id="{{ $folder->id }}"
            data-name-id="{{ $user ? $user->id : '' }}" role="button">
            <i class="bi bi-folder-fill me-2" style="color: {{ $folder->color ?? '#ebc034' }}; font-size:20px;"></i>
            {{ $folder->nombre }}
        </a>
    </div>

    <!-- Colapsable para carpetas hijas -->
    <div class="collapse ms-3" id="folder-{{ $folder->id }}">
        @if ($folder->carpetasHijas->count() > 0)
            <ul class="list-unstyled mb-0">
                @foreach ($folder->carpetasHijas as $subfolder)
                    <li>
                        @include('partials.folder-tree', ['folder' => $subfolder])
                    </li>
                @endforeach
            </ul>
        @endif
    </div>
</div>
