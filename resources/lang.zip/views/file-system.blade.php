@extends('layouts.app')
<style>
    #upload-btn {
        padding: 15px 30px;
        /* Aumentar el padding */
        font-size: 1.2rem;
        /* Tamaño de fuente más grande */
        border-radius: 8px;
        /* Bordes redondeados */
        transition: background-color 0.3s, transform 0.2s, box-shadow 0.3s;
        /* Transiciones suaves */
        background-color: #007bff;
        /* Color de fondo */
        border: none;
        /* Sin borde */
    }

    #upload-btn:hover {
        background-color: #0056b3;
        /* Color al pasar el mouse */
        transform: scale(1.05);
        /* Efecto de escala */
        box-shadow: 0 4px 15px rgba(0, 123, 255, 0.5);
        /* Sombra para profundidad */
    }

    #upload-btn i {
        font-size: 1.3rem;
        /* Tamaño del ícono */
    }
</style>
@section('content')
    <div class="container py-5">
        <div class="row">
            <!-- Encabezado -->
            <div class="col-12 mb-3">
                <div class="header bg-primary text-white p-3">
                    <h2>Gestión de Archivos</h2>
                </div>
            </div>

            <!-- Columna de Carpetas -->
            <div class="col-md-3">
                <button class="btn btn-primary mb-3" id="new-folder-btn" data-bs-toggle="modal"
                    data-bs-target="#newFolderModal">+ Nueva Carpeta</button>


                <div class="folder-list">
                    @foreach ($folders as $folder)
                        <div class="folder-item">
                            @include('partials.folder-tree', ['folder' => $folder])
                        </div>
                    @endforeach
                </div>
            </div>

            <!-- Columna de Archivos -->
            <div class="col-md-9">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 id="folder-title"></h4>
                    <div class="text-center my-3">
                        <button class="btn btn-primary btn-lg shadow" id="upload-btn" data-bs-toggle="modal"
                            data-bs-target="#uploadModal">
                            <i class="bi bi-cloud-upload"></i>
                            <span class="ms-2">Upload</span>
                        </button>
                    </div>
                </div>

                <table class="table table-striped" id="file-table">
                    <thead>
                        <tr>
                            <th>icon</th>
                            <th>Nombre</th>
                            <th>Carpeta</th>
                            <th>Fecha Creacion</th>
                            <th>Fecha Actualizacion</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if (isset($folder) && $folder->archivos->isNotEmpty())
                            @foreach ($folder->archivos as $file)
                            @endforeach
                        @else
                            <tr>
                                <td colspan="6">Seleccione una carpeta para ver sus archivos.</td>
                            </tr>
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

<div class="modal fade" id="uploadModal" tabindex="-1" aria-labelledby="uploadModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="uploadModalLabel">Subir Archivos</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="{{ route('archivo.upload_file') }}" id="uploadForm" method="POST"
                    enctype="multipart/form-data">
                    @csrf
                    <div class="mb-4">
                        <label for="folderSelect" class="form-label">Seleccionar Carpeta</label>
                        <select class="form-select" id="folderSelect" name="folder_id" required>
                            <option value="">Seleccione una carpeta</option>
                            @foreach ($folders as $folder)
                                @include('partials.folder-option', ['folder' => $folder, 'level' => 0])
                            @endforeach
                        </select>
                    </div>
                    <div class="dropzone" id="fileDropzone"></div>
                    <small class="form-text text-muted">Puedes seleccionar múltiples archivos.</small>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <button type="button" class="btn btn-primary" id="submitUpload">Subir</button>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="newFolderModal" tabindex="-1" aria-labelledby="newFolderModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newFolderModalLabel">Crear Nueva Carpeta</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="{{ route('mi_unidad.store') }}" method="POST">
                    @csrf <!-- Token de seguridad de Laravel -->
                    <div class="mb-3">
                        <label for="nombre" class="form-label">Nombre de la Carpeta</label>
                        <input type="text" class="form-control" id="nombre" name="nombre" required>
                    </div>
                    <div class="mb-3">
                        <label for="color" class="form-label">Color de la Carpeta</label>
                        <input type="color" class="form-control" id="color" name="color" value="#34B3EB">
                    </div>
                    <div class="mb-3">
                        <label for="parentFolderSelect" class="form-label">Carpeta Padre</label>
                        <select class="form-select" id="parentFolderSelect" name="carpeta_padre_id">
                            <option value="">Seleccione una carpeta</option>
                            @foreach ($folders as $folder)
                                @include('partials.folder-option', ['folder' => $folder, 'level' => 0])
                            @endforeach
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Guardar Carpeta</button>
                </form>
            </div>
        </div>
    </div>
</div>
