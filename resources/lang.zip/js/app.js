import './bootstrap';

import { Calendar } from '@fullcalendar/core';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid'; // Para ver las horas
import interactionPlugin from '@fullcalendar/interaction';
import axios from 'axios';

// Create a new store instance.


document.addEventListener('DOMContentLoaded', function () {
    var calendarEl = document.getElementById('calendar');

    if (calendarEl) {
        var calendar = new Calendar(calendarEl, {
            plugins: [dayGridPlugin, timeGridPlugin, interactionPlugin],
            initialView: 'timeGridWeek',
            slotMinTime: '06:00:00',
            slotMaxTime: '20:00:00',
            selectable: true,
            events: function (fetchInfo, successCallback, failureCallback) {
                axios.get('/calendar/getAppointments')
                    .then(response => {
                        const events = response.data.map(appointment => ({
                            id: appointment.id, // Incluye el ID aquí
                            title: appointment.title,
                            start: appointment.start,
                            end: appointment.end,
                            description: appointment.description, // Asegúrate de incluir cualquier propiedad extra que necesites
                        }));
                        successCallback(events);
                    })
                    .catch(error => {
                        console.error("Error al obtener citas:", error);
                        failureCallback(error);
                    });
            },
            select: function (info) {
                // Mostrar modal para agregar cita
                $('#addAppointmentModal').modal('show');
                document.getElementById('addAppointmentStart').value = info.start.toISOString().slice(0, 16);
                document.getElementById('addAppointmentEnd').value = info.end.toISOString().slice(0, 16);
                document.getElementById('addAppointmentTitle').value = "";
                document.getElementById('addAppointmentDescription').value = "";
            },
            eventClick: function (info) {
                console.log("Evento seleccionado:", info.event); // Agrega esto para ver toda la información del evento
                $('#editAppointmentModal').modal('show');
                document.getElementById('editAppointmentTitle').value = info.event.title;
                document.getElementById('editAppointmentDescription').value = info.event.extendedProps.description;
                document.getElementById('editAppointmentStart').value = info.event.start.toISOString().slice(0, 16);
                document.getElementById('editAppointmentEnd').value = info.event.end.toISOString().slice(0, 16);
                document.getElementById('editAppointmentId').value = info.event.id;
            }
        });

        document.getElementById('addAppointmentForm').onsubmit = function (event) {
            event.preventDefault();
            const title = document.getElementById('addAppointmentTitle').value;
            const description = document.getElementById('addAppointmentDescription').value;
            const start = document.getElementById('addAppointmentStart').value;
            const end = document.getElementById('addAppointmentEnd').value;

            // Agregar un console.log para depurar
            console.log("Guardando cita:", { title, description, start, end });

            axios.post('/calendar/store', {
                title: title,
                description: description,
                start: start,
                end: end,
            }).then(response => {
                calendar.addEvent({
                    id: response.data.id,
                    title: response.data.title,
                    description: response.data.description,
                    start: start,
                    end: end,
                });
                $('#addAppointmentModal').modal('hide');
            }).catch(error => {
                console.error("Error al guardar la cita:", error);
                alert("Hubo un problema al guardar la cita.");
            });
        };



        document.getElementById('editAppointmentForm').onsubmit = function (event) {
            event.preventDefault();
            const id = document.getElementById('editAppointmentId').value; // Obtiene el ID del campo oculto
            const title = document.getElementById('editAppointmentTitle').value;
            const description = document.getElementById('editAppointmentDescription').value;
            const start = document.getElementById('editAppointmentStart').value;
            const end = document.getElementById('editAppointmentEnd').value;

            // Agrega un console.log para depurar
            console.log("Actualizando cita:", { id, title, description, start, end }); // Verifica que el ID no esté vacío

            // Aquí se envía la solicitud PUT
            axios.put(`/calendar/edit/${id}`, {
                title: title,
                description: description,
                start: start,
                end: end,
            }).then(response => {
                // Maneja la respuesta
                const event = calendar.getEventById(id);
                if (event) {
                    event.setProp('title', title);
                    event.setExtendedProp('description', description);  // Asegúrate de incluir la descripción
                    event.setStart(start);
                    event.setEnd(end);
                }
                $('#editAppointmentModal').modal('hide');
            }).catch(error => {
                console.error("Error al actualizar la cita:", error);
                alert("Hubo un problema al actualizar la cita.");
            });
        };


        document.getElementById('deleteAppointmentButton').onclick = function () {
            const id = document.getElementById('editAppointmentId').value;
            console.log(id);
            deleteAppointment(id);
        };


    } else {
        console.error("El elemento del calendario no se encontró.");
    }
    calendar.render();
});

document.addEventListener("DOMContentLoaded", function () {
    const pickr = Pickr.create({
        el: '#color-picker', // Cambia el selector para que coincida con el id
        theme: 'monolith', // Cambia a 'monolith' o 'nano' si prefieres otro tema
        default: '#ebc034', // Color por defecto
        components: {
            preview: true,
            opacity: true,
            hue: true,
            interaction: {
                hex: true,
                rgba: true,
                hsla: true,
                hsva: true,
                input: true,
                clear: true,
                save: true
            }
        }
    });

    // Guardar el color seleccionado en el input oculto
    pickr.on('save', (color) => {
        document.getElementById('color').value = color.toHEXA().toString(); // Cambia el ID del input oculto si es necesario
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const toggles = document.querySelectorAll('.folder-toggle');

    toggles.forEach(toggle => {
        toggle.addEventListener('click', function (e) {
            e.preventDefault();
            const folderId = this.getAttribute('data-folder-id');
            const folderContent = document.getElementById(`folder-${folderId}`);

            // Alternar la clase 'show'
            if (folderContent.classList.contains('show')) {
                folderContent.classList.remove('show');
            } else {
                folderContent.classList.add('show');
            }
        });
    });
});


//cargue de archivos
document.addEventListener("DOMContentLoaded", function () {
    const folderToggles = document.querySelectorAll(".folder-toggle");

    folderToggles.forEach((toggle) => {
        toggle.addEventListener("click", function (e) {
            e.preventDefault();
            const folderId = this.getAttribute("data-folder-id");
            const folderName = this.innerText.trim(); // Obtiene el nombre de la carpeta

            // Llamada al servidor para obtener datos de la carpeta y sus archivos
            fetch(`/file-system/${folderId}/files`)
                .then(response => {
                    if (!response.ok) throw new Error('Network response was not ok');
                    return response.json();
                })
                .then(data => {
                    const fileTableBody = document.querySelector("#file-table tbody");
                    fileTableBody.innerHTML = ""; // Limpiar la tabla
                    const folderTitle = document.querySelector("#folder-title");
                    folderTitle.innerText = folderName;

                    if (data.archivos.length === 0) {
                        const noFilesRow = document.createElement("tr");
                        noFilesRow.innerHTML = `
                            <td colspan="12" class="text-center">
                                <strong>No hay archivos en la carpeta "${folderName}"</strong>
                            </td>`;
                        fileTableBody.appendChild(noFilesRow);
                        return;
                    }

                    // Procesar cada archivo en la carpeta
                    data.archivos.forEach(file => {
                        const formatDate = (dateString) => {
                            const date = new Date(dateString);
                            return date.toLocaleDateString("es-ES", {
                                year: 'numeric',
                                month: 'long',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit',
                            });
                        };

                        // Acceso a las propiedades del archivo y permisos
                        const { id: archivoId, nombre: archivoNombre, permisos, created_at, updated_at } = file;
                        const puedeVer = permisos[0]?.ver === 1;
                        const puedeDescargar = permisos[0]?.descargar === 1;
                        const puedeEditar = permisos[0]?.editar === 1;
                        const puedeEliminar = permisos[0]?.eliminar === 1;
                        const iconoArchivo = obtenerIconoArchivo(archivoNombre);
                        console.log(iconoArchivo);
                        // Crear fila de la tabla para el archivo
                        const row = document.createElement("tr");
                        row.innerHTML = `
                            <td>${iconoArchivo}</td>
                            <td>${archivoNombre}</td>
                            <td>${folderName}</td>
                            <td>${formatDate(created_at)}</td>
                            <td>${formatDate(updated_at)}</td>
                            <td>
                                <div class="file-item">
                                    ${puedeVer ? `<a href="/archivo/${archivoId}" class="btn btn-info btn-sm" title="Ver" target="_blank"><i class="bi bi-eye"></i></a>` :
                                `<button class="btn btn-info btn-sm" disabled title="Sin permisos para ver"><i class="bi bi-eye" style="color: gray;"></i></button>`}
                                    ${puedeDescargar ? `<a href="/archivo/${archivoId}/download" class="btn btn-success btn-sm" title="Descargar"><i class="bi bi-download"></i></a>` :
                                `<button class="btn btn-success btn-sm" disabled title="Sin permisos para descargar"><i class="bi bi-download" style="color: gray;"></i></button>`}
                                </div>
                                 ${puedeEditar ?
                                `<a href="/archivo/${archivoId}/editar" class="btn btn-warning btn-sm" title="Editar" target="_blank">
                                    <i class="bi bi-pencil"></i>
                                </a>` :
                                    `<button class="btn btn-warning btn-sm" disabled title="Sin permisos para editar">
                                    <i class="bi bi-pencil" style="color: gray;"></i>
                                </button>`
                            }
                            </td>`;

                        // Agregar botón de eliminación
                        if (puedeEliminar) {
                            const deleteButton = document.createElement("span");
                            deleteButton.className = "btn btn-danger btn-sm eliminar-btn";
                            deleteButton.setAttribute("data-archivo-id", archivoId);
                            deleteButton.innerHTML = `<i class="bi bi-trash"></i>`;
                            deleteButton.addEventListener('click', () => eliminarArchivo(archivoId, folderId));
                            row.querySelector(".file-item").appendChild(deleteButton);
                        }

                        fileTableBody.appendChild(row);
                    });
                })
                .catch(error => console.error('Error al obtener archivos:', error));
        });
    });
});

//edicion de archivos
function editarArchivo(archivoId) {
    console.log('Iniciando edición para el archivo:', archivoId);
    return axios.get(`/archivo/${archivoId}/editar`)
        .then(response => {
            console.log(response);
            // Si el servidor devuelve una URL para redirigir
            if (response.data.redirect) {
                window.location.href = response.data.redirect; // Redirigir a la URL proporcionada por el servidor
            } else {
                // Manejo de caso donde no hay redirección
                console.error('No se recibió una URL de redirección válida');
            }
        })
        .catch(error => {
            console.error('Error al obtener los datos para editar:', error);
            if (error.response) {
                alert(`Error: ${error.response.data.error || 'Se produjo un error al editar el archivo.'}`);
            }
        });
}
//eliminacion y cargue de archivos
function eliminarArchivo(archivoId, folderId) {
    console.log('ID de la carpeta antes de la eliminación:', folderId);
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    axios.delete(`/archivo/${archivoId}/delete`, {
        headers: {
            'X-CSRF-TOKEN': csrfToken,
            'Content-Type': 'application/json'
        }
    })
        .then(response => {
            console.log('Archivo eliminado:', response.data);
            if (folderId) {
                return axios.get(`/file-system/${folderId}/files`);
            } else {
                console.log('No llegó el folder ID');
            }
        })
        .then(response => {
            const data = response.data;
            const fileTableBody = document.querySelector("#file-table tbody");
            fileTableBody.innerHTML = ""; // Limpiar la tabla

            // Almacenar el nombre de la carpeta
            const folderName = data.nombre;

            if (data.archivos.length === 0) {
                const noFilesRow = document.createElement("tr");
                noFilesRow.innerHTML = `
                <td colspan="12" class="text-center">
                    <strong>No hay archivos en esta carpeta.</strong>
                </td>
            `;
                fileTableBody.appendChild(noFilesRow);
                return; // Salir de la función si no hay archivos
            }

            // Renderizar cada archivo en la tabla
            data.archivos.forEach(file => {
                const { id: archivoId, nombre: archivoNombre, permisos, created_at, updated_at } = file;

                // Permisos
                const puedeVer = permisos[0]?.ver === 1;
                const puedeDescargar = permisos[0]?.descargar === 1;
                const puedeEditar = permisos[0]?.editar === 1;
                const puedeEliminar = permisos[0]?.eliminar === 1;
                const iconoArchivo = obtenerIconoArchivo(archivoNombre);
                console.log(iconoArchivo);
                // Crear fila de la tabla para el archivo
                const row = document.createElement("tr");
                row.innerHTML = `
                <td>${iconoArchivo}</td>
                <td>${archivoNombre}</td>
                <td>${folderName}</td>
                <td>${new Date(created_at).toLocaleDateString("es-ES", { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</td>
                <td>${new Date(updated_at).toLocaleDateString("es-ES", { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</td>
                <td>
                    <div class="file-item">
                        ${puedeVer ?
                        `<a href="/archivo/${archivoId}" class="btn btn-info btn-sm" title="Ver"><i class="bi bi-eye"></i></a>` :
                        `<button class="btn btn-info btn-sm" disabled title="Sin permisos para ver"><i class="bi bi-eye" style="color: gray;"></i></button>`}

                        ${puedeDescargar ?
                        `<a href="/archivo/${archivoId}/download" class="btn btn-success btn-sm" title="Descargar"><i class="bi bi-download"></i></a>` :
                        `<button class="btn btn-success btn-sm" disabled title="Sin permisos para descargar"><i class="bi bi-download" style="color: gray;"></i></button>`}
                    </div>
                </td>
            `;

                // Agregar botón de edición
                if (puedeEditar) {
                    const editButton = document.createElement("span");
                    editButton.className = "btn btn-warning btn-sm editar-btn";
                    editButton.setAttribute("data-archivo-id", archivoId);
                    editButton.setAttribute("data-carpeta-id", folderId);
                    editButton.innerHTML = `<i class="bi bi-pencil"></i>`;
                    editButton.addEventListener('click', () => editarArchivo(archivoId));
                    row.querySelector(".file-item").appendChild(editButton);
                }

                // Agregar botón de eliminación
                if (puedeEliminar) {
                    const deleteButton = document.createElement("span");
                    deleteButton.className = "btn btn-danger btn-sm eliminar-btn";
                    deleteButton.setAttribute("data-archivo-id", archivoId);
                    deleteButton.setAttribute("data-carpeta-id", folderId);
                    deleteButton.innerHTML = `<i class="bi bi-trash"></i>`;
                    deleteButton.addEventListener('click', () => eliminarArchivo(archivoId, folderId));
                    row.querySelector(".file-item").appendChild(deleteButton);
                }

                fileTableBody.appendChild(row);
            });
        })
        .catch(error => {
            console.error('Error al eliminar el archivo:', error);
            if (error.response) {
                console.error('Detalles del error:', error.response.data);
            }
        });
}


//dropzone de las imagenes
Dropzone.autoDiscover = false;
// Inicializa Dropzone
const myDropzone = new Dropzone("#fileDropzone", {
    url: "/admin/mi_unidad/upload", // Cambia esto a la ruta de tu endpoint
    paramName: "file[]", // Utiliza un array para múltiples archivos
    maxFilesize: 10, // Tamaño máximo en MB
    addRemoveLinks: true,
    acceptedFiles: ".jpeg,.jpg,.png,.pdf,.doc,.docx,.xlsx, .pptx",
    autoProcessQueue: true, // Cambiado a false para procesarlo manualmente
    headers: {
        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
    },
    sending: function (file, xhr, formData) {
        // Agrega el folder_id al formData
        const folderId = document.getElementById("folderSelect").value;
        formData.append("folder_id", folderId); // Añade el folder_id al formData
    }
});

// Botón para iniciar subida
document.getElementById("submitUpload").addEventListener("click", function () {
    const folderId = document.getElementById("folderSelect").value;
    if (!folderId) {
        alert("Selecciona una carpeta antes de subir archivos.");
        return;
    }
    myDropzone.processQueue();
});

// Cuando un archivo se sube correctamente, actualiza la lista
myDropzone.on("success", function (file, response) {
    const folderId = document.getElementById("folderSelect").value;
    console.log('Archivo subido correctamente. Actualizando lista en la carpeta ID:', folderId);
    actualizarListaArchivos(folderId);
});

$('#uploadModal').on('hidden.bs.modal', function () {
    myDropzone.removeAllFiles(true);
    document.getElementById("folderSelect").value = "root"; // Reiniciar a la carpeta principal por defecto
});



// Función para actualizar la lista de archivos en la carpeta seleccionada
function actualizarListaArchivos(folderId) {
    // Si folderId es "root", cambia el valor a una cadena vacía para el backend
    const carpetaId = folderId === "root" ? "" : folderId;

    axios.get(`/file-system/${carpetaId}/files`)
        .then(response => {
            const data = response.data;
            const folderName = data.nombre;
            const fileTableBody = document.querySelector("#file-table tbody");
            fileTableBody.innerHTML = ""; // Limpiar tabla actual

            // Manejar caso sin archivos
            if (data.archivos.length === 0) {
                const noFilesRow = document.createElement("tr");
                noFilesRow.innerHTML = `
                    <td colspan="12" class="text-center">
                        <strong>No hay archivos en esta carpeta.</strong>
                    </td>
                `;
                fileTableBody.appendChild(noFilesRow);
                return;
            }

            console.log(data); // Imprimir la estructura de la respuesta para depuración

            // Renderizar cada archivo en la tabla
            data.archivos.forEach(file => {
                const { id: archivoId, nombre: archivoNombre, created_at, updated_at, permisos } = file;
                // Permisos
                const puedeVer = permisos[0]?.ver === 1;
                const puedeDescargar = permisos[0]?.descargar === 1;
                const puedeEditar = permisos[0]?.editar === 1;
                const puedeEliminar = permisos[0]?.eliminar === 1;
                const iconoArchivo = obtenerIconoArchivo(archivoNombre);
                console.log(iconoArchivo);
                // Crear fila de la tabla para el archivo
                const row = document.createElement("tr");
                row.innerHTML = `
                 <td>${iconoArchivo}</td>
                 <td>${archivoNombre}</td>
                 <td>${folderName}</td>
                 <td>${new Date(created_at).toLocaleDateString("es-ES", { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</td>
                 <td>${new Date(updated_at).toLocaleDateString("es-ES", { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</td>
                 <td>
                     <div class="file-item">
                         ${puedeVer ?
                        `<a href="/archivo/${archivoId}" class="btn btn-info btn-sm" title="Ver"><i class="bi bi-eye"></i></a>` :
                        `<button class="btn btn-info btn-sm" disabled title="Sin permisos para ver"><i class="bi bi-eye" style="color: gray;"></i></button>`}

                         ${puedeDescargar ?
                        `<a href="/archivo/${archivoId}/download" class="btn btn-success btn-sm" title="Descargar"><i class="bi bi-download"></i></a>` :
                        `<button class="btn btn-success btn-sm" disabled title="Sin permisos para descargar"><i class="bi bi-download" style="color: gray;"></i></button>`}
                     </div>
                 </td>
             `;

                // Agregar botón de edición
                if (puedeEditar) {
                    const editButton = document.createElement("span");
                    editButton.className = "btn btn-warning btn-sm editar-btn";
                    editButton.setAttribute("data-archivo-id", archivoId);
                    editButton.setAttribute("data-carpeta-id", folderId);
                    editButton.innerHTML = `<i class="bi bi-pencil"></i>`;
                    editButton.addEventListener('click', () => editarArchivo(archivoId));
                    row.querySelector(".file-item").appendChild(editButton);
                }

                // Agregar botón de eliminación
                if (puedeEliminar) {
                    const deleteButton = document.createElement("span");
                    deleteButton.className = "btn btn-danger btn-sm eliminar-btn";
                    deleteButton.setAttribute("data-archivo-id", archivoId);
                    deleteButton.setAttribute("data-carpeta-id", folderId);
                    deleteButton.innerHTML = `<i class="bi bi-trash"></i>`;
                    deleteButton.addEventListener('click', () => eliminarArchivo(archivoId, folderId));
                    row.querySelector(".file-item").appendChild(deleteButton);
                }

                fileTableBody.appendChild(row);
            });
        })
        .catch(error => {
            console.error('Error al actualizar lista de archivos:', error);
        });
}




function obtenerIconoArchivo(nombreArchivo) {
    const extension = nombreArchivo.split('.').pop().toLowerCase();

    switch (extension) {
        case 'pdf':
            return '<span class="material-icons" style="color: red;">description</span>'; // Ícono para PDF
        case 'doc':
        case 'docx':
            return '<span class="material-icons" style="color: blue;">description</span>'; // Ícono para Word
        case 'xls':
        case 'xlsx':
            return '<span class="material-icons" style="color: green;">description</span>'; // Ícono para Excel
        case 'jpg':
        case 'jpeg':
        case 'png':
        case 'gif':
            return '<span class="material-icons" style="color: orange;">image</span>'; // Ícono para imágenes
        case 'txt':
            return '<span class="material-icons">text_snippet</span>'; // Ícono para archivos de texto
        case 'zip':
        case 'rar':
            return '<span class="material-icons">folder_zip</span>'; // Ícono para archivos comprimidos
        default:
            return '<span class="material-icons">insert_drive_file</span>'; // Ícono genérico para otros tipos de archivo
    }
}

function deleteAppointment(id) {
    Swal.fire({
        title: '¿Estás seguro?',
        text: "¡No podrás recuperar esta cita!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, eliminarla!'
    }).then((result) => {
        if (result.isConfirmed) {
            axios.delete(`/calendar/destroy/${id}`)
                .then(response => {
                    if (response.data.success) {
                        // Recargar los eventos después de eliminar
                        Swal.fire(
                            '¡Eliminado!',
                            'La cita ha sido eliminada con éxito.',
                            'success'
                        );

                        location.reload(true);

                    } else {
                        Swal.fire(
                            'Error',
                            response.data.message, // Muestra el mensaje de error
                            'error'
                        );
                    }
                })
                .catch(error => {
                    console.error("Error al eliminar la cita:", error);
                    Swal.fire(
                        'Error',
                        'Hubo un problema al eliminar la cita.',
                        'error'
                    );
                });
        }
    });
}

var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl)
})
